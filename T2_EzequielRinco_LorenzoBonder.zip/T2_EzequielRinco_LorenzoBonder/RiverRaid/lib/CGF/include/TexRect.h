#ifndef TEXRECT_H
#define TEXRECT_H

// Struct to hold texture coords for each frame
struct TexRect
{
    float u1, v1;
    float u2, v2;
};

#endif // TEXRECT_H

