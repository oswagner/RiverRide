/*
 * Remake River Raid;
 * Entretenimento Digital | PUCRS;
 * Prof�: Marcelo Cohen;
 *
 * Developed By Ezequiel Rinco & Lorenzo Bonder;
 */

#include <iostream>
#include <cmath>
#include "Game.h"
#include "PlayState_Solution.h"
#include "InputManager.h"
#include <string>

PlayState PlayState::m_PlayState;

using namespace std;

void PlayState::init()
{
    score = 0;
    gameover = false;
    exploded = false;
    win = false;
    filling[0] = false;
    filling[1] = false;
    filling[2] = false;
    filled[0] = false;
    filled[1] = false;
    filled[2] = false;
    if (!font.loadFromFile("data/fonts/verdana.ttf")) {
        cout << "Cannot load verdana.ttf font!" << endl;
        exit(1);
    }
    text.setFont(font);
    text.setString("                    River Raid 1.0 \n\n -> Pressione 'Enter' para iniciar o jogo\n -> Use as 'Setas' para movimentar a nave\n -> Pressionar 'Espa�o' para atirar\n\n        Developed By Rinco And Bonder");
    text.setCharacterSize(23);
    text.setFillColor(sf::Color::White);
    text.setStyle(sf::Text::Bold);
    text.setPosition(130,2250);

    if (!scoreFont.loadFromFile("data/fonts/FSEX300.ttf")) {
        cout << "Cannot load FSEX300.ttf font!" << endl;
        exit(1);
    }
    string scoreString;
    ostringstream convert;
    convert << score;
    scoreString = convert.str();
    scoreText.setFont(scoreFont);
    scoreText.setString(scoreString);
    scoreText.setCharacterSize(40);
    scoreText.setFillColor(sf::Color::Yellow);
    scoreText.setPosition(400,2705);

    map = new tmx::MapLoader("data/maps");
    map->Load("map.tmx");

    // Mainly plane settings
    moveStates[0] = "move-left";
    moveStates[1] = "move-stop";
    moveStates[2] = "move-right";

    enemyMoveStates[0] = "move-left";
    enemyMoveStates[1] = "move-right";
    enemyMoveStates[2] = "boom";

    for (int i = 0; i < 5; ++i){
        choppers[i].load("data/img/chopper.png",32,32,0,0,0,0,6,1,6);
        choppers[i].setPosition(150+(i*10),2200-(i*400));
        choppers[i].loadAnimation("data/img/chopperanim.xml");
        choppers[i].setAnimation(enemyMoveStates[ENEMYRIGHT]);
        choppers[i].setAnimRate(30);
        choppers[i].play();
        choppers[i].setXspeed(50);
        boats[i].load("data/img/boat.png",64,64,0,0,0,0,4,1,4);
        boats[i].setPosition(150+(i*20),1600-(i*300));
        boats[i].loadAnimation("data/img/boatanim.xml");
        boats[i].setAnimation(enemyMoveStates[ENEMYRIGHT]);
        boats[i].setAnimRate(30);
        boats[i].play();
        boats[i].setXspeed(25);
        if (i<3){
            enemyplanes[i].load("data/img/enemyplane.png",32,32,0,0,0,0,4,1,4);
            enemyplanes[i].setPosition(-10+(i*20),2400-(i*700));
            enemyplanes[i].loadAnimation("data/img/enemyplaneanim.xml");
            enemyplanes[i].setAnimation(enemyMoveStates[ENEMYRIGHT]);
            enemyplanes[i].setAnimRate(30);
            enemyplanes[i].play();
            enemyplanes[i].setXspeed(300);
            fueltanks[i].load("data/img/fueltank.png",64,64,0,0,0,0,3,1,3);
            fueltanks[i].setPosition(200+(i*20),1800-(i*400));
            fueltanks[i].loadAnimation("data/img/fueltankanim.xml");
            fueltanks[i].setAnimation(enemyMoveStates[ENEMYLEFT]);
            fueltanks[i].setAnimRate(30);
            fueltanks[i].play();
            fueltanks[i].setXspeed(0);
        }
    }



    currentDir = STOP;
    player.load("data/img/plane.png",32,32,0,0,0,0,3,1,3);
    player.setPosition(380,2680);
    player.loadAnimation("data/img/planeanim.xml");
    player.setAnimation(moveStates[currentDir]);
    player.setAnimRate(15);
    player.play();

    // Other objects settings
    shooting = false;
    shot.load("data/img/shot.png");
    shot.setPosition(player.getPosition().x,player.getPosition().y);
    shot.setVisible(false);

    backhud.load("data/img/backhud.png");
    backhud.setPosition(0,2720);

    fuelpanel.load("data/img/fuelpanel.png");
    fuelpanel.setPosition(320,2750);

    minfuel = 312;
    maxfuel = 450;
    fuelbar.load("data/img/fuelbar.png");
    fuelbar.setPosition(maxfuel,2750);


    dirx = 0;

    // To define the map movement and speed
    speeding = false;
    slowing = false;
    moverate = 0;

    im = cgf::InputManager::instance();

    im->addKeyInput("space", sf::Keyboard::Space);
    im->addKeyInput("enter", sf::Keyboard::Return);
    im->addKeyInput("up", sf::Keyboard::Up);
    im->addKeyInput("down", sf::Keyboard::Down);
    im->addKeyInput("left", sf::Keyboard::Left);
    im->addKeyInput("right", sf::Keyboard::Right);
    im->addKeyInput("quit", sf::Keyboard::Escape);

    //incluindo audio
    shotSoundBuffer.loadFromFile("data/audio/tiro.wav");
    shotSound.setBuffer(shotSoundBuffer);
    shotSound.setAttenuation(0);

    explosionSoundBuffer.loadFromFile("data/audio/explosao.wav");
    explosionSound.setBuffer(explosionSoundBuffer);
    explosionSound.setAttenuation(0);

    tankSoundBuffer.loadFromFile("data/audio/tank.wav");
    tankSound.setBuffer(tankSoundBuffer);
    tankSound.setAttenuation(0);

    motorSoundBuffer.loadFromFile("data/audio/motor.wav");
    motorSound.setBuffer(motorSoundBuffer);
    motorSound.setAttenuation(0);

    motorSound.setLoop(true);
    motorSound.play();


    cout << "PlayState: Init" << endl;
}

void PlayState::cleanup()
{
    cout << "PlayState: Clean" << endl;
}

void PlayState::pause()
{
    cout << "PlayState: Paused" << endl;
}

void PlayState::resume()
{
    cout << "PlayState: Resumed" << endl;
}

void PlayState::handleEvents(cgf::Game* game)
{
    screen = game->getScreen();
    sf::View view = screen->getView(); // gets the view
    sf::Event event;

    while (screen->pollEvent(event))
    {
        if(event.type == sf::Event::Closed)
            game->quit();
    }

    dirx = 0;
    int newDir = currentDir;

    // Used to start the game
    if(im->testEvent("enter")){
        if(moverate == 0)
            moverate = -5;
        text.setPosition(801,0);
    }

    // Used to shoot
    if(im->testEvent("space")) {
        if (!shooting && moverate != 0){
            shooting = true;
            shot.setVisible(true);
            shot.setPosition(player.getPosition().x, player.getPosition().y);
             // som do tiro
            shotSound.play();
        }
    }

    // Used to speed up
    if(im->testEvent("up")) {
        speeding = true;
        if(moverate>-15 && moverate!=0){
            motorSound.setPitch(motorSound.getPitch()+0.2);
            moverate -= 5;
        }
        speeding = false;
    }

    // Used to slow down
    if(im->testEvent("down")) {
        slowing = true;
        if(moverate<-2 && moverate!=0){
            motorSound.setPitch(motorSound.getPitch()-0.1);
            moverate += 1;
        }
        slowing = false;
    }

    // Used to move the plane left
    if(im->testEvent("left") && moverate != 0) {
        dirx = -1;
        newDir = LEFT;
        if(!shooting)
            shot.setPosition(player.getPosition().x, player.getPosition().y);
    }

    // Used to move the plane right
    if(im->testEvent("right")  && moverate != 0) {
        dirx = 1;
        newDir = RIGHT;
        if(!shooting)
            shot.setPosition(player.getPosition().x, player.getPosition().y);
    }

    if(im->testEvent("quit"))
        game->quit();

    // To properly draw the stopped plane sprite
    if(dirx == 0) {
        newDir = STOP;
        player.pause();
    }

    if(currentDir != newDir) {
        player.setAnimation(moveStates[newDir]);
        currentDir = newDir;
    }
    player.play();

    player.setXspeed(200*dirx);

    if(shooting)
        shot.setYspeed(-700);

    if(shot.getPosition().y<player.getPosition().y-470){
        shooting = false;
        shot.setYspeed(0);
        shot.setVisible(false);
    }
}

void PlayState::update(cgf::Game* game)
{
    string scoreString;
    ostringstream convert;
    convert << score;
    scoreString = convert.str();
    scoreText.setString(scoreString);
    fuelbar.update(game->getUpdateInterval());
    if (moverate!= 0){
        if(fuelbar.getPosition().x < minfuel){
            gameover = true;
            exploded = true;
        }
        fuelbar.setXspeed(-5 + moverate);
        fuelbar.play();
    }else{
        fuelbar.setXspeed(0);
        fuelbar.play();
    }
    shot.update(game->getUpdateInterval());

    if (gameover && !win){
        motorSound.pause();
        gameover = false;
        moverate = 0;
        player.setVisible(false);
        shot.setVisible(false);
        explosionSound.play();
        planexplode.load("data/img/planexplode.png");
        planexplode.setPosition(player.getPosition().x,player.getPosition().y);
        text.setString("Voc� perdeu");
        text.setPosition(330,player.getPosition().y-250);
    }
    if (win){
        motorSound.pause();
        moverate = 0;
        text.setString("Voc� venceu, parab�ns!");
        text.setPosition(260,player.getPosition().y-250);
    }

    for (int i = 0; i < 5; ++i){
        choppers[i].update(game->getUpdateInterval());
        if(choppers[i].getAnimRate()>2 && player.circleCollision(choppers[i]) && ! exploded){
            gameover = true;
            exploded = true;
            choppers[i].setVisible(false);
        }
        if(choppers[i].getPosition().x < 200){
            choppers[i].setXspeed(50);
            choppers[i].setAnimation(enemyMoveStates[ENEMYRIGHT]);
        }
        if(choppers[i].getPosition().x > 600){
            choppers[i].setXspeed(-50);
            choppers[i].setAnimation(enemyMoveStates[ENEMYLEFT]);
        }

        if(shot.bboxCollision(choppers[i]) && shot.isVisible() && choppers[i].getAnimRate()>2) {
            score = score + 100;
            shot.setVisible(false);
            explosionSound.play();
            choppers[i].setXspeed(0);
            choppers[i].setAnimation(enemyMoveStates[ENEMYBOOM]);
            choppers[i].setAnimRate(2);
            choppers[i].play();
        }

        boats[i].update(game->getUpdateInterval());
        if(boats[i].getAnimRate()>2 && player.circleCollision(boats[i]) && ! exploded){
            gameover = true;
            exploded = true;
            boats[i].setVisible(false);
        }
        if(boats[i].getPosition().x < 260){
            boats[i].setXspeed(25);
            boats[i].setAnimation(enemyMoveStates[ENEMYRIGHT]);
        }
        if(boats[i].getPosition().x > 550){
            boats[i].setXspeed(-25);
            boats[i].setAnimation(enemyMoveStates[ENEMYLEFT]);
        }
        if(shot.bboxCollision(boats[i]) && shot.isVisible() && boats[i].getAnimRate()>2) {
            score = score + 100;
            shot.setVisible(false);
            explosionSound.play();
            boats[i].setXspeed(0);
            boats[i].setAnimation(enemyMoveStates[ENEMYBOOM]);
            boats[i].setAnimRate(2);
            boats[i].play();
        }

        if(i<3){
            enemyplanes[i].update(game->getUpdateInterval());
            if(enemyplanes[i].getAnimRate()>2 && player.circleCollision(enemyplanes[i]) && ! exploded){
                gameover = true;
                exploded = true;
                enemyplanes[i].setVisible(false);
            }
            if(enemyplanes[i].getPosition().x < -100){
                enemyplanes[i].setXspeed(300);
                enemyplanes[i].setAnimation(enemyMoveStates[ENEMYRIGHT]);
            }
            if(enemyplanes[i].getPosition().x > 900){
                enemyplanes[i].setXspeed(-300);
                enemyplanes[i].setAnimation(enemyMoveStates[ENEMYLEFT]);
            }

            if(shot.bboxCollision(enemyplanes[i]) && shot.isVisible() && enemyplanes[i].getAnimRate()>2) {
                score = score + 100;
                shot.setVisible(false);
                explosionSound.play();
                enemyplanes[i].setXspeed(0);
                enemyplanes[i].setAnimation(enemyMoveStates[ENEMYBOOM]);
                enemyplanes[i].setAnimRate(2);
                enemyplanes[i].play();
            }

            fueltanks[i].update(game->getUpdateInterval());
            if(fueltanks[i].getAnimRate()>2 && player.circleCollision(fueltanks[i]) && ! filled[i]){
                    filling[i] = true;
            }

            if(shot.bboxCollision(fueltanks[i]) && shot.isVisible() && fueltanks[i].getAnimRate()>2) {
                shot.setVisible(false);
                explosionSound.play();
                fueltanks[i].setAnimation(enemyMoveStates[ENEMYBOOM]);
                fueltanks[i].setAnimRate(2);
                fueltanks[i].play();
            }

            if (filling[i]){
                for (int i = 0; i < 30; ++i){
                    if (fuelbar.getPosition().x < maxfuel)
                        fuelbar.setPosition(fuelbar.getPosition().x+1, fuelbar.getPosition().y);
                }
                tankSound.play();
                filled[i] = true;
                filling[i] = false;
            }
        }
    }

    checkCollision(1, game, &player);
    moveMap();
}

void PlayState::draw(cgf::Game* game)
{
    screen = game->getScreen();
    map->Draw(*screen);
    screen->draw(text);

    for (int i = 0; i < 5; ++i){
        screen->draw(choppers[i]);
        screen->draw(boats[i]);
        if(i<3){
            screen->draw(enemyplanes[i]);
            screen->draw(fueltanks[i]);
        }
    }
    screen->draw(backhud);
    screen->draw(fuelbar);

    screen->draw(fuelpanel);
    screen->draw(player);
    screen->draw(planexplode);
    screen->draw(shot);
    screen->draw(scoreText);
}

// Method to update the screen as well as the speed of movement
void PlayState::moveMap()
{
    if(!speeding && moverate < -5){
        motorSound.setPitch(motorSound.getPitch()-0.2);
        moverate +=5;
    }

    if(!slowing && moverate > -5 && moverate < 0){
        motorSound.setPitch(motorSound.getPitch()+0.1);
        moverate -=1;
    }

    if(player.getPosition().y<480){
        moverate = 0;
        win = true;
    }

    sf::View view = screen->getView();

    backhud.setPosition((backhud.getPosition().x),(backhud.getPosition().y)+moverate);
    fuelbar.setPosition((fuelbar.getPosition().x),(fuelbar.getPosition().y)+moverate);
    fuelpanel.setPosition((fuelpanel.getPosition().x),(fuelpanel.getPosition().y)+moverate);
    player.setPosition((player.getPosition().x),(player.getPosition().y)+moverate);
    shot.setPosition((shot.getPosition().x),(shot.getPosition().y)+moverate);
    scoreText.setPosition((scoreText.getPosition().x),(scoreText.getPosition().y)+moverate);

    view.setCenter(sf::Vector2f(400,player.getPosition().y-170));
    screen->setView(view);
}

bool PlayState::checkCollision(uint8_t layer, cgf::Game* game, cgf::Sprite* obj)
{
    int i, x1, x2, y1, y2;
    bool bump = false;

    // Get the limits of the map
    sf::Vector2u mapsize = map->GetMapSize();
    // Get the width and height of a single tile
    sf::Vector2u tilesize = map->GetMapTileSize();

    mapsize.x /= tilesize.x;
    mapsize.y /= tilesize.y;
    mapsize.x--;
    mapsize.y--;

    // Get the height and width of the object (in this case, 100% of a tile)
    sf::Vector2u objsize = obj->getSize();
    objsize.x *= obj->getScale().x;
    objsize.y *= obj->getScale().y;

    float px = obj->getPosition().x;
    float py = obj->getPosition().y;

    double deltaTime = game->getUpdateInterval();

    sf::Vector2f offset(obj->getXspeed()/1000 * deltaTime, obj->getYspeed()/1000 * deltaTime);

    float vx = offset.x;
    float vy = offset.y;

    // Test the horizontal movement first
    i = objsize.y > tilesize.y ? tilesize.y : objsize.y;

    for (;;)
    {
        x1 = (px + vx) / tilesize.x;
        x2 = (px + vx + objsize.x - 1) / tilesize.x;

        y1 = (py) / tilesize.y;
        y2 = (py + i - 1) / tilesize.y;

        if (x1 >= 0 && x2 < mapsize.x && y1 >= 0 && y2 < mapsize.y)
        {
            if (vx > 0)
            {
                // Trying to move right

                int upRight   = getCellFromMap(layer, x2*tilesize.x, y1*tilesize.y);
                int downRight = getCellFromMap(layer, x2*tilesize.x, y2*tilesize.y);
                if (upRight || downRight)
                {
                    // Place the player as close to the solid tile as possible
                    px = x2 * tilesize.x;
                    px -= objsize.x;// + 1;
                    vx = 0;
                    bump = true;
                }
            }

            else if (vx < 0)
            {
                // Trying to move left

                int upLeft   = getCellFromMap(layer, x1*tilesize.x, y1*tilesize.y);
                int downLeft = getCellFromMap(layer, x1*tilesize.x, y2*tilesize.y);
                if (upLeft || downLeft)
                {
                    // Place the player as close to the solid tile as possible
                    px = (x1+1) * tilesize.x;
                    vx = 0;
                    bump = true;
                }
            }
        }

        if (i == objsize.y) // Checked player height with all tiles ?
        {
            break;
        }

        i += tilesize.y; // done, check next tile upwards

        if (i > objsize.y)
        {
            i = objsize.y;
        }
    }

    // Now test the vertical movement

    i = objsize.x > tilesize.x ? tilesize.x : objsize.x;

    for (;;)
    {
        x1 = (px / tilesize.x);
        x2 = ((px + i-1) / tilesize.x);

        y1 = ((py + vy) / tilesize.y);
        y2 = ((py + vy + objsize.y-1) / tilesize.y);

        if (x1 >= 0 && x2 < mapsize.x && y1 >= 0 && y2 < mapsize.y)
        {
            if (vy > 0)
            {
                // Trying to move down
                int downLeft  = getCellFromMap(layer, x1*tilesize.x, y2*tilesize.y);
                int downRight = getCellFromMap(layer, x2*tilesize.x, y2*tilesize.y);
                if (downLeft || downRight)
                {
                    // Place the player as close to the solid tile as possible
                    py = y2 * tilesize.y;
                    py -= objsize.y;
                    vy = 0;
                    bump = true;
                }
            }

            else if (vy < 0)
            {
                // Trying to move up

                int upLeft  = getCellFromMap(layer, x1*tilesize.x, y1*tilesize.y);
                int upRight = getCellFromMap(layer, x2*tilesize.x, y1*tilesize.y);
                if (upLeft || upRight)
                {
                    // Place the player as close to the solid tile as possible
                    py = (y1 + 1) * tilesize.y;
                    vy = 0;
                    bump = true;
                }
            }
        }

        if (i == objsize.x)
        {
            break;
        }

        i += tilesize.x; // done, check next tile to the right

        if (i > objsize.x)
        {
            i = objsize.x;
        }
    }

    // Now apply the movement and animation

    obj->setPosition(px+vx,py+vy);
    px = obj->getPosition().x;
    py = obj->getPosition().y;

    obj->update(deltaTime, false); // only update animation

    // Check collision with edges of map
    if (px < 0)
        obj->setPosition(px,py);
    else if (px + objsize.x >= mapsize.x * tilesize.x)
        obj->setPosition(mapsize.x*tilesize.x - objsize.x - 1,py);

    if(py < 0)
        obj->setPosition(px,0);
    else if(py + objsize.y >= mapsize.y * tilesize.y)
        obj->setPosition(px, mapsize.y*tilesize.y - objsize.y - 1);

    return bump;
}

// Get a cell GID from the map (x and y in global coords)
sf::Uint16 PlayState::getCellFromMap(uint8_t layernum, float x, float y)
{
    auto layers = map->GetLayers();
    tmx::MapLayer& layer = layers[layernum];
    sf::Vector2u mapsize = map->GetMapSize();
    sf::Vector2u tilesize = map->GetMapTileSize();
    mapsize.x /= tilesize.x;
    mapsize.y /= tilesize.y;
    int col = floor(x / tilesize.x);
    int row = floor(y / tilesize.y);
    return layer.tiles[row*mapsize.x + col].gid;
}
