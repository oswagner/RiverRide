/*
 * Remake River Raid;
 * Entretenimento Digital | PUCRS;
 * Prof�: Marcelo Cohen;
 *
 * Developed By Ezequiel Rinco & Lorenzo Bonder;
 */

#ifndef PLAY_STATE_H_
#define PLAY_STATE_H_

#include "GameState.h"
#include "Sprite.h"
#include "InputManager.h"
#include <tmx/MapLoader.h>
#include <string>

class PlayState : public cgf::GameState
{
    public:

    void init();
    void cleanup();

    void pause();
    void resume();

    void handleEvents(cgf::Game* game);
    void update(cgf::Game* game);
    void draw(cgf::Game* game);

    static PlayState* instance()
    {
        return &m_PlayState;
    }

    protected:

    PlayState() {}

    private:

    static PlayState m_PlayState;

    enum { LEFT=0, STOP, RIGHT };
    enum { ENEMYLEFT=0, ENEMYRIGHT, ENEMYBOOM };
    std::string moveStates[3];
    std::string enemyMoveStates[3];
    int currentDir;
    int chopperDir;

    int dirx;
    int minfuel, maxfuel;
    int moverate;
    int score;
    bool shooting;
    bool speeding, slowing;
    bool gameover, exploded, win;
    bool filling[3];
    bool filled[3];

    cgf::Sprite backhud;
    cgf::Sprite player;
    cgf::Sprite shot;
    cgf::Sprite fuelpanel;
    cgf::Sprite fuelbar;
    cgf::Sprite planexplode;

    cgf::Sprite choppers[5];
    cgf::Sprite boats[5];
    cgf::Sprite enemyplanes[3];

    cgf::Sprite fueltanks[3];

    sf::RenderWindow* screen;
    cgf::InputManager* im;

    tmx::MapLoader* map;

    sf::Font font;
    sf::Font scoreFont;
    sf::Text text;
    sf::Text scoreText;
    //incluindo som
    sf::SoundBuffer shotSoundBuffer;
    sf::Sound shotSound;

    sf::SoundBuffer explosionSoundBuffer;
    sf::Sound explosionSound;

    sf::SoundBuffer tankSoundBuffer;
    sf::Sound tankSound;

    sf::SoundBuffer motorSoundBuffer;
    sf::Sound motorSound;

    // Centers the camera on the player position and redraws hud elements
    void moveMap();

    // Checks collision between a sprite and a map layer
    bool checkCollision(uint8_t layer, cgf::Game* game, cgf::Sprite* obj);

    // get a cell GID from the map (x and y in world coords)
    sf::Uint16 getCellFromMap(uint8_t layernum, float x, float y);
};

#endif
