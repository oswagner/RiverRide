Linux: instale pacote libglew-dev
Windows: use a DLL nas opcoes de link (glew32.dll, do diretorio bin)
