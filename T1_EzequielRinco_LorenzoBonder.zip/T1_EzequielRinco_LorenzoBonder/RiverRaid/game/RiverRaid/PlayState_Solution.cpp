/*
 * Remake River Raid;
 * Entretenimento Digital | PUCRS;
 * Prof�: Marcelo Cohen;
 *
 * Developed By Ezequiel Rinco & Lorenzo Bonder;
 */


#include <iostream>
#include <cmath>
#include "Game.h"
#include "PlayState_Solution.h"
#include "InputManager.h"

PlayState PlayState::m_PlayState;

using namespace std;

void PlayState::init()
{

    if (!font.loadFromFile("data/fonts/verdana.ttf")) {
        cout << "Cannot load verdana.ttf font!" << endl;
        exit(1);
    }
    text.setFont(font);
    text.setString("                    River Raid 1.0 \n\n -> Pressione 'Enter' para iniciar o jogo\n -> Use as 'Setas' para movimentar a nave\n -> Pressionar 'Espa�o' para atirar\n\n        Developed By Rinco And Bonder");
    text.setCharacterSize(23);
    text.setFillColor(sf::Color::White);
    text.setStyle(sf::Text::Bold);
    text.setPosition(130,2250);

    map = new tmx::MapLoader("data/maps");
    map->Load("map.tmx");

    // Configura��es Principais da Nave
    moveStates[0] = "move-left";
    moveStates[1] = "move-stop";
    moveStates[2] = "move-right";
    currentDir = STOP;
    player.load("data/img/plane.png",32,32,0,0,0,0,3,1,3);
    player.setPosition(380,2680);
    player.loadAnimation("data/img/planeanim.xml");
    player.setAnimation(moveStates[currentDir]);
    player.setAnimRate(15);
    player.play();

    // Configura��es de outros objetos
    shooting = false;
    shot.load("data/img/shot.png");
    shot.setPosition(player.getPosition().x,player.getPosition().y);

    backhud.load("data/img/backhud.png");
    backhud.setPosition(0,2720);

    fuelpanel.load("data/img/fuelpanel.png");
    fuelpanel.setPosition(320,2750);

    minfuel = 312;
    maxfuel = 450;
    fuelbar.load("data/img/fuelbar.png");
    fuelbar.setPosition(maxfuel,2750);

    dirx = 0;

    // Movimento e velocidade do Mapa
    speeding = false;
    slowing = false;
    moverate = 0;

    im = cgf::InputManager::instance();

    im->addKeyInput("space", sf::Keyboard::Space);
    im->addKeyInput("enter", sf::Keyboard::Return);
    im->addKeyInput("up", sf::Keyboard::Up);
    im->addKeyInput("down", sf::Keyboard::Down);
    im->addKeyInput("left", sf::Keyboard::Left);
    im->addKeyInput("right", sf::Keyboard::Right);
    im->addKeyInput("quit", sf::Keyboard::Escape);

    // Implementado para testar o combust�vel
    im->addKeyInput("f1", sf::Keyboard::F1);
    im->addKeyInput("f2", sf::Keyboard::F2);


    cout << "PlayState: Init" << endl;
}

void PlayState::cleanup()
{
    cout << "PlayState: Clean" << endl;
}

void PlayState::pause()
{
    cout << "PlayState: Paused" << endl;
}

void PlayState::resume()
{
    cout << "PlayState: Resumed" << endl;
}

void PlayState::handleEvents(cgf::Game* game)
{
    screen = game->getScreen();
    sf::View view = screen->getView();
    sf::Event event;

    while (screen->pollEvent(event))
    {
        if(event.type == sf::Event::Closed)
            game->quit();
    }

    dirx = 0;
    int fuelDir = 0;
    int newDir = currentDir;

    // Usado para testar o combust�vel
    if(im->testEvent("f1") && moverate != 0)
        fuelDir = -1;
    if(im->testEvent("f2") && moverate != 0)
        fuelDir = 1;

    // 'Enter' para iniciar o jogo
    if(im->testEvent("enter")){
        if(moverate == 0)
            moverate = -5;
        text.setPosition(801,0);
    }

    // 'Espa�o' usado para atirar
    if(im->testEvent("space")) {
        if (!shooting && moverate != 0){
            shooting = true;
            shot.setPosition(player.getPosition().x, player.getPosition().y);
        }
    }

    // 'UP' para acelerar o mapa
    if(im->testEvent("up")) {
        speeding = true;
        if(moverate>-15)
            moverate -= 5;
        speeding = false;
    }

    // 'Down' para freiar o mapa
    if(im->testEvent("down")) {
        slowing = true;
        if(moverate<-2)
            moverate += 1;
        slowing = false;
    }

    // 'Left' move a nave para esquerda
    if(im->testEvent("left") && moverate != 0) {
        dirx = -1;
        newDir = LEFT;
        if(!shooting)
            shot.setPosition(player.getPosition().x, player.getPosition().y);
    }

    // 'Right' move a nave para direita
    if(im->testEvent("right")  && moverate != 0) {
        dirx = 1;
        newDir = RIGHT;
        if(!shooting)
            shot.setPosition(player.getPosition().x, player.getPosition().y);
    }

    if(im->testEvent("quit"))
        game->quit();

    // Nave no estado de pausa
    if(dirx == 0) {
        newDir = STOP;
        player.pause();
    }

    if(currentDir != newDir) {
        player.setAnimation(moveStates[newDir]);
        currentDir = newDir;
    }
    player.play();

    player.setXspeed(200*dirx);

    // Para deslocar a barra de medi��o do combust�vel
    if((fuelbar.getPosition().x < minfuel && fuelDir < 0) || (fuelbar.getPosition().x > maxfuel && fuelDir > 0)){
        fuelDir = 0;
        if(fuelbar.getPosition().x < minfuel)
            fuelbar.setPosition(minfuel,fuelbar.getPosition().y);
        else
            fuelbar.setPosition(maxfuel,fuelbar.getPosition().y);
    }
    fuelbar.setXspeed(15*fuelDir);

    if(shooting)
        shot.setYspeed(-700);

    if(shot.getPosition().y<player.getPosition().y-470){
        shooting = false;
        shot.setYspeed(0);
    }
}

void PlayState::update(cgf::Game* game)
{
    fuelbar.update(game->getUpdateInterval());
    shot.update(game->getUpdateInterval());
    player.update(game->getUpdateInterval());
    moveMap();
}

void PlayState::draw(cgf::Game* game)
{
    screen = game->getScreen();
    map->Draw(*screen);
    screen->draw(text);
    screen->draw(backhud);
    screen->draw(fuelbar);
    screen->draw(fuelpanel);
    screen->draw(player);
    screen->draw(shot);

}

// Atualiza a tela e a velocidade do jogo.
void PlayState::moveMap()
{
    if(!speeding && moverate < -5)
        moverate +=5;

    if(!slowing && moverate > -5 && moverate < 0)
        moverate -=1;

    if(player.getPosition().y<480)
        moverate = 0;

    sf::View view = screen->getView();

    backhud.setPosition((backhud.getPosition().x),(backhud.getPosition().y)+moverate);
    fuelbar.setPosition((fuelbar.getPosition().x),(fuelbar.getPosition().y)+moverate);
    fuelpanel.setPosition((fuelpanel.getPosition().x),(fuelpanel.getPosition().y)+moverate);
    player.setPosition((player.getPosition().x),(player.getPosition().y)+moverate);
    shot.setPosition((shot.getPosition().x),(shot.getPosition().y)+moverate);

    view.setCenter(sf::Vector2f(400,player.getPosition().y-170));
    screen->setView(view);
}
