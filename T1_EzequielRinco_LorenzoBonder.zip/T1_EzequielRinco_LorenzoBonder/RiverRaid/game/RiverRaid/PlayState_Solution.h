/*
 * Remake River Raid;
 * Entretenimento Digital | PUCRS;
 * Prof�: Marcelo Cohen;
 *
 * Developed By Ezequiel Rinco & Lorenzo Bonder;
 */

#ifndef PLAY_STATE_H_
#define PLAY_STATE_H_

#include "GameState.h"
#include "Sprite.h"
#include "InputManager.h"
#include <tmx/MapLoader.h>
#include <string>

class PlayState : public cgf::GameState
{
    public:

    void init();
    void cleanup();

    void pause();
    void resume();

    void handleEvents(cgf::Game* game);
    void update(cgf::Game* game);
    void draw(cgf::Game* game);

    static PlayState* instance()
    {
        return &m_PlayState;
    }

    protected:

    PlayState() {}

    private:

    static PlayState m_PlayState;

    enum { LEFT=0, STOP, RIGHT };
    std::string moveStates[3];
    int currentDir;

    int dirx;
    int minfuel, maxfuel;
    int moverate;
    bool shooting;
    bool speeding, slowing;

    cgf::Sprite backhud;
    cgf::Sprite player;
    cgf::Sprite shot;
    cgf::Sprite fuelpanel;
    cgf::Sprite fuelbar;
    sf::RenderWindow* screen;
    cgf::InputManager* im;

    tmx::MapLoader* map;

    sf::Font font;
    sf::Text text;

    // Centers the camera on the player position and redraws hud elements
    void moveMap();
};

#endif
